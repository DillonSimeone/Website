"use strict";

// TODO: Create an array of image filenames (e.g., image1.jpg, image2.jpg, etc.)

// TODO: Get references to DOM elements: the image and the two buttons

// TODO: Add event listeners for the buttons to cycle images forward and backward

// TODO: Add fade-out class before image changes, then remove it after timeout

document.addEventListener("DOMContentLoaded", () => {
    // Code here
});
