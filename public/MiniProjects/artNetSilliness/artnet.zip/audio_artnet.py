import sys
import os
import time
import ctypes
import subprocess
import colorsys
import socket
import json
import threading
import webbrowser
import numpy as np
import sounddevice as sd
from stupidArtnet import StupidArtnet

# ==============================================================================
# CONFIGURATION
# ==============================================================================
TARGET_IP = '192.168.0.100'  # The IP of your Art-Net controller
PIXELS_PER_PORT = 1250       # Pixels per port (updated dynamically)
TOTAL_UNIVERSES_TO_SEND = 32 # Broad block of universes to broadcast to

PIXELS_PER_UNIVERSE = 170
CHANNELS_PER_UNIVERSE = 512

FPS = 45
AUDIO_SAMPLE_RATE = 44100
FFT_WINDOW_SIZE = 4096

# Visualizer parameters (updated dynamically via UDP control)
visualizer_settings = {
    "animation": "spectrum",
    "pixels": 1250,
    "gain": 5.0,
    "smoothing": 0.7,
    "threshold": 0.001
}
running = True
node_process = None
settings_lock = threading.Lock()
# ==============================================================================


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def relaunch_as_admin():
    print("[*] Requesting Administrator privileges to configure network adapter...")
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()

def get_ethernet_interface():
    """Auto-detect the first active physical Ethernet adapter name."""
    try:
        cmd = ["powershell", "-Command",
               "Get-NetAdapter -Physical | Where-Object { $_.Name -like '*Ethernet*' } | Select-Object -ExpandProperty Name"]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        names = [line.strip() for line in res.stdout.split('\n') if line.strip()]
        if names:
            return names[0]
        cmd = ["powershell", "-Command",
               "Get-NetAdapter -Physical | Where-Object { $_.Name -notlike '*Wi-Fi*' } | Select-Object -ExpandProperty Name"]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        names = [line.strip() for line in res.stdout.split('\n') if line.strip()]
        if names:
            return names[0]
    except Exception as e:
        print(f"[!] Error detecting network adapter: {e}")
    return None

def configure_network_ip(interface_name, static_ip="192.168.0.101", subnet_mask="255.255.255.0"):
    print(f"[*] Configuring '{interface_name}' to static IP {static_ip}...")
    try:
        cmd = f'netsh interface ipv4 set address name="{interface_name}" static {static_ip} {subnet_mask}'
        res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if res.returncode == 0:
            print("[+] Ethernet interface configured successfully!")
            return True
        else:
            print(f"[!] Failed to configure Ethernet: {res.stderr.strip()}")
    except Exception as e:
        print(f"[!] Error running netsh: {e}")
    return False

# Global audio buffer
audio_buffer = np.zeros(FFT_WINDOW_SIZE)

def audio_callback(indata, frames, time_info, status):
    global audio_buffer
    if status:
        print(status, file=sys.stderr)
    audio_buffer = np.roll(audio_buffer, -frames)
    audio_buffer[-frames:] = indata[:, 0]


def udp_listener_thread():
    """UDP listener to receive settings updates from Node.js Express server."""
    global visualizer_settings, running
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('127.0.0.1', 9999))
    sock.settimeout(0.5)
    
    print("[+] UDP Control socket listening on 127.0.0.1:9999")
    
    while running:
        try:
            data, addr = sock.recvfrom(2048)
            msg = json.loads(data.decode('utf-8'))
            
            if msg.get('command') == 'shutdown':
                print("[*] Shutdown signal received from Web UI.")
                running = False
                break
                
            # Update settings safely using a Lock
            with settings_lock:
                for key in visualizer_settings:
                    if key in msg:
                        visualizer_settings[key] = msg[key]
                    
        except socket.timeout:
            continue
        except Exception as e:
            print(f"[!] Error in UDP listener: {e}")
            
    sock.close()


def main():
    global running, node_process, PIXELS_PER_PORT
    
    if not is_admin():
        relaunch_as_admin()

    print("====================================================")
    print("      Art-Net Web-Controlled Audio Visualizer Engine")
    print("====================================================")
    
    # 1. Automate Ethernet Configuration
    adapter = get_ethernet_interface()
    if adapter:
        print(f"[+] Found adapter: {adapter}")
        configure_network_ip(adapter, "192.168.0.101", "255.255.255.0")
    else:
        print("[!] Warning: No physical Ethernet adapter detected. Skipping network config.")

    # 2. Start UDP listener in background
    listener_thread = threading.Thread(target=udp_listener_thread)
    listener_thread.daemon = True
    listener_thread.start()

    # 3. Start Express.js server
    print("[*] Launching Express.js control panel backend...")
    try:
        node_process = subprocess.Popen(["node", "server.js"], shell=True)
        time.sleep(1.5) # Wait for server to boot up
    except Exception as e:
        print(f"[!] Failed to start Node.js server. Is node installed? Error: {e}")

    # 4. Open Website Page
    print("[*] Opening Control Center UI in browser...")
    webbrowser.open("http://localhost:3000")

    # 5. Initialize Art-Net clients
    print(f"[*] Initializing {TOTAL_UNIVERSES_TO_SEND} Art-Net clients...")
    artnet_clients = {}
    universe_buffers = {}
    for univ in range(TOTAL_UNIVERSES_TO_SEND):
        client = StupidArtnet(TARGET_IP, univ, CHANNELS_PER_UNIVERSE, FPS, True, True)
        client.start()
        artnet_clients[univ] = client
        universe_buffers[univ] = bytearray(CHANNELS_PER_UNIVERSE)

    # 6. Setup Audio Capture
    try:
        stream = sd.InputStream(
            channels=1,
            samplerate=AUDIO_SAMPLE_RATE,
            blocksize=512,
            callback=audio_callback
        )
        stream.start()
        print("[+] Audio input stream started successfully!")
    except Exception as e:
        print(f"[!] Failed to start audio input: {e}")
        running = False

    # Function to allocate/re-allocate arrays when pixel count changes
    def init_pixel_arrays(pixel_count):
        freqs = np.zeros(pixel_count)
        hues = np.zeros(pixel_count)
        for idx in range(pixel_count):
            freq = (idx / (pixel_count - 1)) * 20000.0 if pixel_count > 1 else 0.0
            freqs[idx] = freq
            hues[idx] = (freq / 20000.0) * 0.8
        
        amplitudes = np.zeros(pixel_count)
        wave_buf = np.zeros((pixel_count, 3))
        fire_buf = np.zeros(pixel_count)
        
        return freqs, hues, amplitudes, wave_buf, fire_buf

    PIXELS_PER_PORT = visualizer_settings["pixels"]
    pixel_freqs, pixel_hues, pixel_amplitudes, wave_buffer, fire_buffer = init_pixel_arrays(PIXELS_PER_PORT)
    
    # State tracking variables for animations
    hue_cycle_tracker = 0.0

    print("\n[+] System running. Go to http://localhost:3000 to manage animations.")
    print("Press Ctrl+C to close.")

    try:
        frame_time = 1.0 / FPS
        while running:
            t_start = time.time()
            
            # Fetch visualizer variables locally under lock
            with settings_lock:
                anim = visualizer_settings["animation"]
                gain = visualizer_settings["gain"]
                smoothing = visualizer_settings["smoothing"]
                threshold = visualizer_settings["threshold"]
                target_pixels = visualizer_settings["pixels"]

            # Check if pixel count has changed dynamically
            if target_pixels != PIXELS_PER_PORT:
                print(f"[*] Dynamically resizing pixels to: {target_pixels}")
                PIXELS_PER_PORT = target_pixels
                pixel_freqs, pixel_hues, pixel_amplitudes, wave_buffer, fire_buffer = init_pixel_arrays(PIXELS_PER_PORT)

            # Compute FFT
            windowed_audio = audio_buffer * np.hanning(FFT_WINDOW_SIZE)
            fft_res = np.abs(np.fft.rfft(windowed_audio))
            df = AUDIO_SAMPLE_RATE / FFT_WINDOW_SIZE
            
            # Map FFT bins to raw amplitudes
            raw_amplitudes = np.zeros(PIXELS_PER_PORT)
            for i in range(PIXELS_PER_PORT):
                freq = pixel_freqs[i]
                bin_idx = int(freq / df)
                amp = fft_res[bin_idx] if bin_idx < len(fft_res) else 0.0
                emphasis_factor = 1.0 + (freq / 1500.0)
                raw_amplitudes[i] = amp * emphasis_factor

            # Temporal smoothing
            pixel_amplitudes = (pixel_amplitudes * smoothing) + (raw_amplitudes * (1.0 - smoothing))

            rgb_data = []

            # ------------------------------------------------------------------
            # ANIMATION 1: SPECTRUM ANALYZER
            # ------------------------------------------------------------------
            if anim == "spectrum":
                for i in range(PIXELS_PER_PORT):
                    val = pixel_amplitudes[i] * gain
                    if val < threshold:
                        val = 0.0
                    val = min(1.0, val)
                    r, g, b = colorsys.hsv_to_rgb(pixel_hues[i], 1.0, val)
                    rgb_data.append((int(r * 255), int(g * 255), int(b * 255)))

            # ------------------------------------------------------------------
            # ANIMATION 2: BASS PULSE
            # ------------------------------------------------------------------
            elif anim == "bass":
                bass_bins = int(250.0 / df)
                bass_power = np.mean(fft_res[:bass_bins]) if bass_bins > 0 else 0.0
                val = bass_power * gain
                if val < threshold:
                    val = 0.0
                val = min(1.0, val)

                hue_cycle_tracker = (hue_cycle_tracker + 0.003) % 1.0
                r, g, b = colorsys.hsv_to_rgb(hue_cycle_tracker, 1.0, val)
                rgb_val = (int(r * 255), int(g * 255), int(b * 255))
                rgb_data = [rgb_val] * PIXELS_PER_PORT

            # ------------------------------------------------------------------
            # ANIMATION 3: VU METER (SYMMETRICAL)
            # ------------------------------------------------------------------
            elif anim == "vu":
                rms = np.sqrt(np.mean(audio_buffer**2))
                val = rms * gain
                if val < threshold:
                    val = 0.0
                val = min(1.0, val)

                lit_count = int(val * (PIXELS_PER_PORT // 2))
                center = PIXELS_PER_PORT // 2
                
                temp_colors = [(0, 0, 0)] * PIXELS_PER_PORT
                for idx in range(lit_count):
                    pos_ratio = idx / (PIXELS_PER_PORT // 2)
                    hue = pos_ratio * 0.8
                    r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
                    color = (int(r * 255), int(g * 255), int(b * 255))
                    
                    if center + idx < PIXELS_PER_PORT:
                        temp_colors[center + idx] = color
                    if center - idx >= 0:
                        temp_colors[center - idx] = color
                rgb_data = temp_colors

            # ------------------------------------------------------------------
            # ANIMATION 4: COLOR WAVE (PROPERTIES OUTWARD FROM CENTER)
            # ------------------------------------------------------------------
            elif anim == "wave":
                # Roll left and right halves outwards from center
                mid = PIXELS_PER_PORT // 2
                
                if mid > 0:
                    # Scroll left half leftwards
                    wave_buffer[:mid] = np.roll(wave_buffer[:mid], -1, axis=0)
                    # Scroll right half rightwards
                    wave_buffer[mid:] = np.roll(wave_buffer[mid:], 1, axis=0)
                
                # Fetch audio attributes
                rms = np.sqrt(np.mean(audio_buffer**2))
                val = rms * gain
                if val < threshold:
                    val = 0.0
                val = min(1.0, val)

                peak_freq_idx = np.argmax(fft_res)
                peak_freq = peak_freq_idx * df
                hue = min(0.8, (peak_freq / 8000.0) * 0.8) if peak_freq > 0 else 0.0
                
                # Inject peak color in the center
                r, g, b = colorsys.hsv_to_rgb(hue, 1.0, val)
                rgb_val = [int(r * 255), int(g * 255), int(b * 255)]
                
                if mid < PIXELS_PER_PORT:
                    wave_buffer[mid] = rgb_val
                if mid - 1 >= 0:
                    wave_buffer[mid - 1] = rgb_val
                
                # Copy wave buffer to DMX frame
                for i in range(PIXELS_PER_PORT):
                    rgb_data.append((int(wave_buffer[i][0]), int(wave_buffer[i][1]), int(wave_buffer[i][2])))

            # ------------------------------------------------------------------
            # ANIMATION 5: RAINBOW SCROLL
            # ------------------------------------------------------------------
            elif anim == "rainbow":
                hue_cycle_tracker = (hue_cycle_tracker + 0.005) % 1.0
                rms = np.sqrt(np.mean(audio_buffer**2))
                brightness = rms * gain
                if brightness < threshold:
                    brightness = 0.0
                brightness = min(1.0, brightness)

                for i in range(PIXELS_PER_PORT):
                    hue = (i / PIXELS_PER_PORT + hue_cycle_tracker) % 1.0
                    r, g, b = colorsys.hsv_to_rgb(hue, 1.0, brightness)
                    rgb_data.append((int(r * 255), int(g * 255), int(b * 255)))

            # ------------------------------------------------------------------
            # ANIMATION 6: FIRE SIMULATION (PROPAGATING HEAT)
            # ------------------------------------------------------------------
            elif anim == "fire":
                # Cooling down of particles
                fire_buffer = fire_buffer * 0.94
                # Propagate upwards/outwards
                fire_buffer = np.roll(fire_buffer, 1)
                
                # Read low bass transients to trigger heat
                bass_bins = int(250.0 / df)
                bass_power = np.mean(fft_res[:bass_bins]) if bass_bins > 0 else 0.0
                heat = bass_power * gain
                if heat < threshold:
                    heat = 0.0
                fire_buffer[0] = min(1.0, heat)
                
                for i in range(PIXELS_PER_PORT):
                    h = fire_buffer[i]
                    if h < 0.15:
                        rgb_data.append((0, 0, 0))
                    elif h < 0.55:
                        # Red to Orange gradient
                        r = int(h * 1.8 * 255)
                        g = int(max(0.0, h - 0.15) * 0.5 * 255)
                        rgb_data.append((min(255, r), min(255, g), 0))
                    else:
                        # Yellow to White gradient
                        r = 255
                        g = int(h * 255)
                        b = int((h - 0.55) * 2.2 * 255)
                        rgb_data.append((r, min(255, g), min(255, b)))

            # ------------------------------------------------------------------
            # ANIMATION 7: HIGH SPARKLE
            # ------------------------------------------------------------------
            elif anim == "sparkle":
                # Find high frequencies (> 6000 Hz)
                treble_bins = int(6000.0 / df)
                treble_power = np.mean(fft_res[treble_bins:]) if len(fft_res) > treble_bins else 0.0
                treble_val = treble_power * gain
                
                # Slow morphing background color
                hue_cycle_tracker = (hue_cycle_tracker + 0.001) % 1.0
                bg_r, bg_g, bg_b = colorsys.hsv_to_rgb(hue_cycle_tracker, 1.0, 0.08)
                bg_color = (int(bg_r * 255), int(bg_g * 255), int(bg_b * 255))
                
                rgb_data = [bg_color] * PIXELS_PER_PORT
                
                if treble_val > threshold * 2.5:
                    num_sparkles = int(min(25, treble_val * 40))
                    for _ in range(num_sparkles):
                        idx = np.random.randint(0, PIXELS_PER_PORT)
                        rgb_data[idx] = (255, 255, 255)

            # Fallback if empty
            if not rgb_data:
                rgb_data = [(0, 0, 0)] * PIXELS_PER_PORT

            # Distribute precomputed RGB data across active universes
            universes_per_port = int(np.ceil(PIXELS_PER_PORT / PIXELS_PER_UNIVERSE))
            for univ in range(TOTAL_UNIVERSES_TO_SEND):
                u_offset = univ % universes_per_port
                pix_start = u_offset * PIXELS_PER_UNIVERSE
                pix_end = min(pix_start + PIXELS_PER_UNIVERSE, PIXELS_PER_PORT)
                
                buf = bytearray(CHANNELS_PER_UNIVERSE)
                for p in range(pix_start, pix_end):
                    offset = (p - pix_start) * 3
                    r, g, b = rgb_data[p]
                    buf[offset]     = r
                    buf[offset + 1] = g
                    buf[offset + 2] = b
                
                artnet_clients[univ].set(buf)
                artnet_clients[univ].show()

            t_elapsed = time.time() - t_start
            time.sleep(max(0.001, frame_time - t_elapsed))
            
    except KeyboardInterrupt:
        print("\n[*] Exiting visualizer...")
    finally:
        # Shutdown stream
        if 'stream' in locals():
            stream.stop()
            stream.close()
            
        # Stop Art-Net
        for client in artnet_clients.values():
            client.blackout()
            client.stop()
            
        # Kill server process
        if node_process:
            print("[*] Stopping Web Control Panel backend...")
            node_process.terminate()
            node_process.kill()
            
        print("[+] System closed cleanly.")

if __name__ == "__main__":
    main()
