%TF.GenerationSoftware,tscircuit,circuit-json-to-gerber,0.0.77*%
%TF.CreationDate,2026-10-28T02:16:08.317Z*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Profile,NP*%
%FSLAX46Y46*%
%MOMM*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by tscircuit (builder) date 2026-10-28T02:16:08.317Z*
G01*
%LPD*%
G75*
%ADD10C,0.050000*%
D10*
X-19000000Y-19000000D02*
X019000000Y-19000000D01*
X019000000Y019000000D01*
X-19000000Y019000000D01*
X-19000000Y-19000000D01*
M02*