%TF.GenerationSoftware,tscircuit,circuit-json-to-gerber,0.0.77*%
%TF.CreationDate,2026-10-15T05:14:01.509Z*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Profile,NP*%
%FSLAX46Y46*%
%MOMM*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by tscircuit (builder) date 2026-10-15T05:14:01.509Z*
G01*
%LPD*%
G75*
%ADD10C,0.050000*%
D10*
X-11000000Y-55000000D02*
X011000000Y-55000000D01*
X011000000Y055000000D01*
X-11000000Y055000000D01*
X-11000000Y-55000000D01*
M02*