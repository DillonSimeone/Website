%TF.GenerationSoftware,tscircuit,circuit-json-to-gerber,0.0.77*%
%TF.CreationDate,2026-10-15T05:13:13.564Z*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Profile,NP*%
%FSLAX46Y46*%
%MOMM*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by tscircuit (builder) date 2026-10-15T05:13:13.564Z*
G01*
%LPD*%
G75*
%ADD10C,0.050000*%
D10*
X-35000000Y-05000000D02*
X035000000Y-05000000D01*
X035000000Y005000000D01*
X-35000000Y005000000D01*
X-35000000Y-05000000D01*
M02*