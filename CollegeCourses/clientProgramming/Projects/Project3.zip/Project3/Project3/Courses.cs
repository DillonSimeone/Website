﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    public class Courses
    {
        public string degreeName { get; set; }
        public string semester { get; set; }
        public List<string> courses { get; set; }
    }
}
