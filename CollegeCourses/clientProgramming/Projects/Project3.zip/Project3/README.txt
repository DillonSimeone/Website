Project 3
By Dillon Simeone

Phew. 

Extra:
	I feel that I did really great with the backended part of this project. Look inside the regions on line 280 and 376. I managed a way to get previous/next buttons to work perfectly with the contents that's parsed from the JSON files.
	
	One of the more complex bit of the codes happens on line 439, where the code depends on an exact tabpage being already loaded. It checks if that page is loaded. If it's not loaded, it'll force that page to load then it's able to access the resouces it need.
	
	However, without doubt, I would say that the most complex part of my code starts on line 600. The courses page. I found a way to parse the JArray into objects, and to access the first child of each tabs in the tabpage to fill in the right infomation and implemented a way to filter out the useless data that appears in the array. That one stumped me for a bit!