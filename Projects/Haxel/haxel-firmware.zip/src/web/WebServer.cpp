#ifdef HAXEL_WIFI

#include "WebServer.h"
#include "ApiHandlers.h"
#include "../core/Engine.h"
#include "../core/Config.h"
#include "../core/AudioAnalyzer.h"
#include "../core/Pattern.h"
#include <LittleFS.h>
#include <WiFi.h>
#include <ArduinoJson.h>

namespace haxel::web {

class CaptiveRequestHandler : public AsyncWebHandler {
public:
    CaptiveRequestHandler(Config* config) : config_(config) {}
    virtual ~CaptiveRequestHandler() {}

    bool canHandle(AsyncWebServerRequest *request) const override {
        String host = request->host();
        int colonIndex = host.indexOf(':');
        if (colonIndex != -1) {
            host = host.substring(0, colonIndex);
        }
        if (host != "192.168.4.1" && host != "haxel.local" && host != config_->hostname() + ".local") {
            return true;
        }
        return false;
    }

    void handleRequest(AsyncWebServerRequest *request) override {
        AsyncWebServerResponse *response = request->beginResponse(302, "text/plain", "");
        response->addHeader("Location", "http://192.168.4.1/");
        response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response->addHeader("Pragma", "no-cache");
        response->addHeader("Expires", "-1");
        request->send(response);
    }
private:
    Config* config_;
};

bool WebServer::begin(core::Engine* engine, Config* config, core::AudioAnalyzer* audio) {
    engine_ = engine;
    config_ = config;
    audio_  = audio;
    server_ = new AsyncWebServer(80);
    ws_     = new AsyncWebSocket("/ws");

    // Wildcard DNS redirect handler registered FIRST
    server_->addHandler(new CaptiveRequestHandler(config_));

    // Order matters: AsyncWebServer iterates handlers in registration order.
    // API + WebSocket + captive probes register FIRST so they match before the
    // static-file fallback (which would otherwise serve index.html for
    // anything that wasn't an existing file).
    mountWebsocket_();
    mountJsonApi_();
    mountWlenApi_();
    mountCaptiveProbes_();
    mountStatic_();   // fallback / SPA shell

    server_->begin();
    return true;
}

void WebServer::stop() {
    if (server_) { server_->end(); delete server_; server_ = nullptr; }
    if (ws_)     { delete ws_; ws_ = nullptr; }
}

void WebServer::broadcastState() {
    if (!ws_ || !engine_ || ws_->count() == 0) return;
    ws_->cleanupClients();
    JsonDocument doc;
    doc["type"] = "state";
    auto data = doc["data"].to<JsonObject>();
    core::StagedState s;
    engine_->copyState(s);
    data["on"] = s.on;
    data["mute"] = s.mute;
    data["intensity"] = s.intensity;
    data["speed"] = s.speed;
    data["pattern"] = s.pattern ? s.pattern->id() : "";
    data["startupFloor"] = s.startupFloor;
    data["numBins"] = s.numBins;

    auto divs = data["dividers"].to<JsonArray>();
    for (int i = 0; i < s.numBins - 1 && i < 4; ++i) {
        divs.add(s.dividers[i]);
    }

    auto binPats = data["binPatterns"].to<JsonArray>();
    for (int i = 0; i < s.numBins && i < 5; ++i) {
        binPats.add(s.binPatterns[i]);
    }

    String body;
    serializeJson(doc, body);
    ws_->textAll(body);
}

void WebServer::mountStatic_() {
    // No-store so reflashing the LittleFS image always serves the latest UI on
    // next page load. Bandwidth on a captive portal is irrelevant.
    server_->serveStatic("/", LittleFS, "/")
        .setDefaultFile("index.html")
        .setCacheControl("no-store, max-age=0");
}

void WebServer::mountJsonApi_() {
    ApiHandlers::install(*server_, engine_, config_, audio_);
}

void WebServer::mountWlenApi_() {
    server_->on("/win", HTTP_GET, [this](AsyncWebServerRequest* req) {
        ApiHandlers::handleWlenWin(req, engine_);
    });
}

void WebServer::mountWebsocket_() {
    ws_->onEvent([this](AsyncWebSocket* server, AsyncWebSocketClient* client,
                        AwsEventType type, void* arg, uint8_t* data, size_t len) {
        ApiHandlers::handleWebSocket(server, client, type, arg, data, len, engine_, config_);
    });
    server_->addHandler(ws_);
}

void WebServer::mountCaptiveProbes_() {
    auto redirect = [](AsyncWebServerRequest* req) {
        AsyncWebServerResponse* r = req->beginResponse(302, "text/plain", "");
        r->addHeader("Location", "/");
        req->send(r);
    };
    for (const char* path : {
        "/generate_204","/gen_204","/hotspot-detect.html",
        "/library/test/success.html","/connectivity-check.html",
        "/connectivity-check.txt","/ncsi.txt"
    }) {
        server_->on(path, HTTP_GET, redirect);
    }
    server_->onNotFound([](AsyncWebServerRequest* req) {
        const String& url = req->url();
        // API paths must NEVER receive an HTML redirect  Eclients expect JSON
        // (or 404 text). Returning HTML here is what makes fetch().json() blow up.
        if (url.startsWith("/json") || url.startsWith("/win") || url == "/ws") {
            req->send(404, "application/json",
                      String("{\"error\":\"no route\",\"path\":\"") + url + "\"}");
            return;
        }
        // If the URL is already root, redirecting to root would cause an infinite redirection loop.
        // This typically happens if index.html is missing in LittleFS.
        if (url == "/" || url == "/index.html") {
            req->send(404, "text/html",
                      "<html><head><title>Haxel Portal Error</title>"
                      "<style>body{font-family:sans-serif;background:#121212;color:#fff;text-align:center;padding:50px;}"
                      "h1{color:#ff6a3d;}</style></head><body>"
                      "<h1>Haxel Portal Error</h1>"
                      "<p>Error 404: Web UI files not found in LittleFS filesystem.</p>"
                      "<p>Please upload the data partition (LittleFS image) to the ESP32.</p>"
                      "</body></html>");
            return;
        }
        // For everything else (captive portal probes, unknown SPA paths),
        // redirect to root so the SPA can handle it client-side.
        AsyncWebServerResponse* r = req->beginResponse(302, "text/plain", "");
        r->addHeader("Location", "/");
        req->send(r);
    });
}

} // namespace haxel::web

#endif // HAXEL_WIFI
