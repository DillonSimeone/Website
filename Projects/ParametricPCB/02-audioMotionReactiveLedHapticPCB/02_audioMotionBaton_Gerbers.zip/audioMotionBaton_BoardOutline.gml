%TF.GenerationSoftware,tscircuit,circuit-json-to-gerber,0.0.77*%
%TF.CreationDate,2026-10-15T05:13:30.013Z*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Profile,NP*%
%FSLAX46Y46*%
%MOMM*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by tscircuit (builder) date 2026-10-15T05:13:30.013Z*
G01*
%LPD*%
G75*
%ADD10C,0.050000*%
D10*
X-10000000Y-60000000D02*
X010000000Y-60000000D01*
X010000000Y060000000D01*
X-10000000Y060000000D01*
X-10000000Y-60000000D01*
M02*