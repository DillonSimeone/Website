%TF.GenerationSoftware,tscircuit,circuit-json-to-gerber,0.0.77*%
%TF.CreationDate,2026-10-28T02:15:55.781Z*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
%MOMM*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by tscircuit (builder) date 2026-10-28T02:15:55.781Z*
G01*
%LPD*%
G75*
G04 APERTURE MACROS START*
%AMHORZPILL*
0 Horizontal pill (stadium) shape macro*
0 Parameters:*
0 $1 = Total width*
0 $2 = Total height*
0 $3 = Circle diameter (equal to height)*
0 $4 = Circle center offset
0 21 = Center Line(Exposure, Width, Height, Center X, Center Y, Rotation)*
0 1 = Circle(Exposure, Diameter, Center X, Center Y, Rotation)*
21,1,$1-$3,$2,0.0,0.0,0.0*
1,1,$3,0.0-$4,0.0*
1,1,$3,$4,0.0*%
%AMVERTPILL*
0 Vertical pill (stadium) shape macro*
0 Parameters:*
0 $1 = Total width*
0 $2 = Total height*
0 $3 = Circle diameter (equal to width)*
0 $4 = Circle center offset
0 21 = Center Line(Exposure, Width, Height, Center X, Center Y, Rotation)*
21,1,$1,$2-$3,0.0,0.0,0.0*
1,1,$3,0.0,0.0-$4*
1,1,$3,0.0,$4*%
%AMROUNDRECT*
0 Rectangle with rounded corners*
0 $1 Corner radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y Position of each corner*
0 Polygon box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Circles for rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Rectangles between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 APERTURE MACROS END*
G04 aperture START LIST*
%ADD10C,0.250000*%
%ADD11C,0.150000*%
%ADD12C,5.000000*%
%ADD13C,1.750000*%
%ADD14R,0.800000X0.900000*%
%ADD15R,0.560000X0.630000*%
%ADD16C,1.900000*%
%ADD17C,0.125000*%
%ADD18C,0.500000*%
%ADD19C,0.100000*%
%ADD20C,0.200000*%
%ADD21C,0.187500*%
%ADD22C,0.450000*%
%TD*%
G04 aperture END LIST*
D12*
X-16500000Y016500000D03*
D12*
X016500000Y016500000D03*
D12*
X-16500000Y-16500000D03*
D12*
X016500000Y-16500000D03*
D13*
X-08890000Y010890000D03*
D13*
X-08890000Y008350000D03*
D13*
X-08890000Y005810000D03*
D13*
X-08890000Y003270000D03*
D13*
X-08890000Y000730000D03*
D13*
X-08890000Y-01810000D03*
D13*
X-08890000Y-04350000D03*
D13*
X-08890000Y-06890000D03*
D13*
X008890000Y010890000D03*
D13*
X008890000Y008350000D03*
D13*
X008890000Y005810000D03*
D13*
X008890000Y003270000D03*
D13*
X008890000Y000730000D03*
D13*
X008890000Y-01810000D03*
D13*
X008890000Y-04350000D03*
D13*
X008890000Y-06890000D03*
D14*
X-08300000Y-11500000D03*
D14*
X-06700000Y-11500000D03*
D14*
X006700000Y-11500000D03*
D14*
X008300000Y-11500000D03*
D14*
X006700000Y-15200000D03*
D14*
X008300000Y-15200000D03*
D16*
X-03810000Y-16500000D03*
D16*
X-01270000Y-16500000D03*
D16*
X001270000Y-16500000D03*
D16*
X003810000Y-16500000D03*
M02*